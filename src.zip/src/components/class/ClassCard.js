import React from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { doc, deleteDoc, updateDoc, arrayRemove } from "firebase/firestore";
import { db } from "../../firebase/Config";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";

const ClassCard = ({ classItem }) => {
  const { user } = useAuth();
  const { setClasses, setUsers } = useData();

  const authUser = user.id === classItem.createdBy;

  const handleDelete = async (classId) => {
    if (authUser) {
      try {
        await deleteDoc(doc(db, "classes", classId));
        setClasses((prev) =>
          prev ? prev?.filter((classItem) => classItem.id !== classId) : []
        );

        await updateDoc(doc(db, "users", classItem.createdBy), {
          allClasses: arrayRemove(classId),
          updatedAt: new Date().toISOSting(),
        });
        setUsers((prev) => prev?.map((u) => u.id === user.id));
        toast.success("Class deleted successfully");
      } catch (err) {
        console.error("Error deleting class:", err.code, err.message);
        toast.error("Failed to delete class. Please try again.");
      }
    } else {
      toast.warning("Only the creator of the class can delete it.");
    }
  };

  return (
    <tr>
      <td>
        <Link to={`/classes/${classItem.id}`}>{classItem.title}</Link>
      </td>
      <td>{classItem.description}</td>
      <td>{classItem.location}</td>
      <td>{classItem.capacity}</td>
      <td>
        {classItem.schedule?.map((s, index) => (
          <div key={index}>
            <strong>{s.day}</strong>: {s.startTime} - {s.endTime}
          </div>
        ))}
      </td>

      <td>
        {authUser ? (
          <>
            <Link
              to={`/classes/edit/${classItem.id}`}
              className="btn btn-primary btn-sm me-2"
            >
              Edit
            </Link>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => handleDelete(classItem.id)}
            >
              Delete
            </button>
          </>
        ) : (
          <p className="text-muted mb-0 text-center fw-bold fs-6">
            You are not the creator of this class.
          </p>
        )}
      </td>
    </tr>
  );
};

export default ClassCard;
