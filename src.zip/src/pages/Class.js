import React from "react";
import ClassList from "../components/class/ClassList";

const Class = () => {
  return (
    <>
      <ClassList />
    </>
  );
};

export default Class;
